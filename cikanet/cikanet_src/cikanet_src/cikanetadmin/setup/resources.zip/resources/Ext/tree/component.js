// define the namespaces
jmaki.namespace("jmaki.widgets.Ext.tree");

jmaki.widgets.Ext.tree.Widget = function(wargs) {
    var self = this;
    var topic = "/Ext/tree";

    this.tree = new Ext.tree.TreePanel(wargs.uuid,{
                animate:true, 
                enableDD:true,
                containerScroll: true,
                dropConfig: {appendOnly:true}});

    if (wargs.args && wargs.args.topic) {
        topic = wargs.args.topic;
    }
    // use the default tree found in the widget.json if none is provided
    if (!wargs.value ) {
        // default to the service in the widget.json if a value has not been st
        // and if there is no service
        if (typeof wargs.service == 'undefined') {
            wargs.service = wargs.widgetDir + "/widget.json";
            var callback = function(req) {
                if (req.readyState == 4) {
                    var obj = eval("(" + req.responseText + ")");
                    var jTree = obj.root;
                    var _root = jTree.root;
                    self.root = new Ext.tree.TreeNode({
                        text: _root.label, 
                        draggable:false, // disable root node dragging
                        expanded : true,
                        id:'source'
                    });
                    self.root.children = _root.children;
                    self.tree.setRootNode(self.root);
                    self.tree.render();    
                    buildTree(self.root);
                }
            }
           
        } else {
            var _callback = function(req) {
                if (req.readyState == 4) {
                    var jTree = eval("(" + req.responseText + ")");
                    var _root = jTree.root;
                    alert(_root);
                    self.root = new Ext.tree.TreeNode({
                        text: _root.label, 
                        draggable:false, // disable root node dragging
                        expanded : true,
                        id:'source'
                    });
                    self.root.children = _root.children;
                    self.tree.setRootNode(self.root);
                    self.tree.render();
                    buildTree(self.root);                    
                }
            }        
        }
         var ajax = jmaki.doAjax({url : wargs.service, callback : _callback});
    } else if (typeof wargs.value == 'object') {
      
        if (wargs.value.root.title && !wargs.value.root.label) {
          wargs.value.root.label = wargs.value.root.title;
        }
       // set the root node
      self.root = new Ext.tree.TreeNode({
              text: wargs.value.root.label, 
             draggable:false, // disable root node dragging
             expanded : true,
              id:'source'
      });
      self.root.children = wargs.value.root.children;
      self.tree.setRootNode(self.root);
      self.tree.render();    
      buildTree(self.root);
    }

    // now build the tree programtically
    function buildTree(_root, parent) {

        var rChildren = false;
        var rExpanded = false;
        if (_root.children) rChildren = true;
        if (_root.expanded && (_root.expanded == true || _root.expanded == "true")) rExpanded = true;
          
        for (var t = 0; _root.children && t < _root.children.length; t++) {
            var n = _root.children[t];
            var hasChildren = false;
            if (n.children) hasChildren = true;
            if (n.title && !n.label) {
                n.label = n.title;
            }
            var lNode = new Ext.tree.TreeNode({
                text: n.label,
                expanded : rExpanded,
                draggable:false, // disable root node dragging
                id:'source'});
                _root.appendChild(lNode);            
                if (n.onclick) {
                    var _m = n.onclick;
                    _m.title = n.label;
                    lNode.addListener("dblclick",function(e){_m.event = e;jmaki.publish(topic,_m);});
                }
                //  recursively call buildTree to add children
                if (n.children) {
                    lNode.children = n.children;
                    buildTree(lNode);
                }       
        }
    } 
}